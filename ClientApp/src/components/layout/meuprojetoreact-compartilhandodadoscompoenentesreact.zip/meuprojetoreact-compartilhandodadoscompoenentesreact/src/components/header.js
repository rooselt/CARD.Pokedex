import React from 'react';

const Header = () => (
    <header>
        <h1>Meu Projeto React</h1>
    </header>
);

export default Header;