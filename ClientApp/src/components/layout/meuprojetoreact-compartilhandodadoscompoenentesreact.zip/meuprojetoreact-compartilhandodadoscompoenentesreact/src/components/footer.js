import React from 'react';

const Footer = () => (
    <footer>
        <p>&copy; 2019</p>
    </footer>
);

export default Footer;