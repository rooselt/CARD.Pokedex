import React from 'react';

const Contato = () => (
    <div className="title">
        <h4>Contato</h4>
        <p>Me contate pelos seguintes canais.</p>
    </div>
);

export default Contato;